#!/bin/bash

identityUser=$(sh /Library/Addigy/auditor-facts/scripts/identity_users | cut -f1 -d '@')

#echo "$identityUser"
sudo /usr/sbin/scutil --set HostName "$identityUser"
sudo /usr/sbin/scutil --set ComputerName "$identityUser"
sudo /usr/sbin/scutil --set LocalHostName "$identityUser"