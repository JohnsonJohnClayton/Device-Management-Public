#!/bin/bash

# Addigy Zendesk ticket 64475
# Get the currently logged in user
currentUser=$(stat -f%Su /dev/console)
# Get the Serial Number of the Computer
sn=$(system_profiler SPHardwareDataType | awk '/Serial/ {print $4}')
# Get the device type
deviceType=$(system_profiler SPHardwareDataType | awk '/Model Name/ {print $3}')
#deviceValue=$(if [[ "$deviceType" = "MacBook" ]]; then
#	echo "L"
#	else
#	echo "D"
#	fi)

if [[ "$currentUser" == "pnadmin" ]]; then
	currentUser="unassigned"
	#echo $currentUser
else
	echo "Legit user"
fi

# Set the ComputerName, HostName and LocalHostNamerose
scutil --set ComputerName "$currentUser-$deviceType-$sn"
scutil --set HostName "$currentUser-$deviceType-$sn"
scutil --set LocalHostName "$currentUser-$deviceType-$sn"