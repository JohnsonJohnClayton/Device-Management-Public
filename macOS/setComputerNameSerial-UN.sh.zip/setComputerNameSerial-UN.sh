#!/bin/bash

#Resources
#https://community.jamf.com/t5/jamf-pro/trying-to-find-the-best-way-to-rename-computers-after-enrollment/m-p/247384
#https://community.jamf.com/t5/jamf-pro/script-to-name-computers-to-serialnumber/td-p/139526

# Get the logged in user
userName=$(/bin/ls -la /dev/console | /usr/bin/cut -d " " -f 4)

echo $userName

# Get the Serial Number of the Computer
sn=$(system_profiler SPHardwareDataType | awk '/Serial/ {print $4}')

# Set the ComputerName, HostName and LocalHostName
scutil --set ComputerName "$userName-$sn"
scutil --set HostName "$userName-$sn"
scutil --set LocalHostName "$userName-$sn"